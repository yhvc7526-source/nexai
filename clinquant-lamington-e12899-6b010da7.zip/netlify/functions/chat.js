exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };
  try {
    const { message } = JSON.parse(event.body || '{}');
    if (!message) return { statusCode: 400, body: JSON.stringify({error:'Пустое сообщение'}) };
    const key = process.env.GEMINI_API_KEY;
    if (!key) return { statusCode: 500, body: JSON.stringify({error:'API-ключ GEMINI_API_KEY не добавлен в Netlify'}) };
    const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`, {
      method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({contents:[{parts:[{text:message}]}]})
    });
    const data = await resp.json();
    if (!resp.ok) return {statusCode:resp.status, body:JSON.stringify({error:data.error?.message||'Ошибка Gemini'})};
    const reply = data.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('') || 'Не удалось получить ответ.';
    return {statusCode:200,headers:{'Content-Type':'application/json'},body:JSON.stringify({reply})};
  } catch (e) { return {statusCode:500,body:JSON.stringify({error:e.message})}; }
};
